# TOOLS.md - Configurações Locais

## Dashboard GEO (Finanças Pessoais)

**URL:** http://localhost:3003
**API Base:** http://localhost:3003/api

### Autenticação
Para gerar novo token:


### Endpoints principais
- GET /api/reminders?status=active - Lembretes pendentes
- POST /api/reminders - Criar lembrete
- GET /api/dashboard/summary - Resumo financeiro
- GET /api/transactions - Transações recentes

## Fluxo R10 (Finanças Empresa)

**URL:** http://localhost:3004
**API Base:** http://localhost:3004/api

### Credenciais
- Email: george@r10piaui.com
- Senha: r10@2025

## WhatsApp do George

**Número:** 558699689881

Para enviar mensagem proativa, use o comando message do clawdbot.
