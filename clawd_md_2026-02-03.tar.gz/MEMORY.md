# MEMORY.md

Long-term facts, preferences, and durable context.

## User Preferences

- Comunicação direta e objetiva
- Horário ativo: 07:00 às 23:00
- Idioma: Português brasileiro
- Não usar emojis em excesso

## Important Facts

- **Sistema financeiro:** r10.geolabs.com.br
- **Servidor Contabo:** 173.249.57.88
- **WhatsApp GEO:** +5511972342811

## Context

- GEO migrado para Clawdbot em 26/01/2026
- Espera personalidade forte e proativa
- Parceiro, não assistente passivo

## Decisions Made

(Adicionar decisões importantes aqui)

---
*Update this file when you learn something durable about the user or make significant decisions.*
